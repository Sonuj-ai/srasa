# GUDIYA BEAUTIQUE — ONLINE CLOUD SETUP GUIDE

Aapka software ab offline (`START_PRO.bat` / `127.0.0.1`) aur **online cloud** (`gunicorn server:app`) dono mode ke liye tayyar hai.

## Step 1: GitHub Par Files Upload Karein
1. `Gudiya_Beautique_Parlour_Cloud_Suite-v57.zip` ko extract karein.
2. GitHub par ek repository banayein (jaise `gudiya-beautique-suite`) aur extracted folder ki sabhi files (`server.py`, `pro_ui.html`, `schema.sql`, `Procfile`, `requirements.txt`, `render.yaml`, `manifest.json`, `sw.js`, `backups/`, `product_images/`) upload kar dein.

## Step 2: Render / Cloud Hosting Par Live Karein
1. Render (render.com) ya kisi Python WSGI cloud host par **New -> Web Service** chunein aur apni GitHub repository connect karein.
2. Build Command: `pip install -r requirements.txt`
3. Start Command: `gunicorn server:app --bind 0.0.0.0:$PORT --workers 2 --threads 4`
4. **Environment Variables** me zaroori values set karein:
   - `APP_PIN` = apna secret PIN (optional, agar online login PIN chahiye)
   - Agar persistent storage/disk attach karte hain to `DB_PATH`, `BACKUP_DIR`, `IMAGES_DIR` set karein.

## Step 3: Kisi Bhi Jagah Se Online Open Karein
- Deploy hone ke baad aapko ek live `https://...` URL mil jayega.
- Us `https://` link ko mobile, tablet, ya kisi doosre PC ke browser me open karke aap online billing, parlour entries, customer `BAKI` dues, aur product/god images ka use kar sakte hain.
