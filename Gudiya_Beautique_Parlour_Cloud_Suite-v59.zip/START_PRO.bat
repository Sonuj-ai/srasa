@echo off
setlocal
TITLE GUDIYA BEAUTIQUE
cd /d "%~dp0"
if not exist "RUN" mkdir "RUN"
(
echo @echo off
echo cd /d "%%~dp0.."
echo call "START_PRO.bat"
) > "RUN\START_PRO.bat"
SET "APP_PORT=56672"

echo ==================================================
echo   STARTING GUDIYA BEAUTIQUE SOFTWARE...
echo   FOLDER: %CD%
echo ==================================================

powershell -NoProfile -Command "$pids = Get-NetTCPConnection -LocalPort %APP_PORT% -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique; if ($pids) { Stop-Process -Id $pids -Force -ErrorAction SilentlyContinue; Start-Sleep -Milliseconds 500 }" >nul 2>nul

set "PY_CMD="
where python >nul 2>nul && set "PY_CMD=python"
if not defined PY_CMD (
    where py >nul 2>nul && set "PY_CMD=py -3"
)
if not defined PY_CMD (
    where python3 >nul 2>nul && set "PY_CMD=python3"
)

if not defined PY_CMD (
    echo.
    echo [ERROR] Python nahi mila!
    echo Kripya python.org se Python install karein aur "Add Python to PATH" tick karein.
    echo.
    pause
    exit /b 1
)

start "" "http://127.0.0.1:%APP_PORT%/"
%PY_CMD% server.py
echo.
echo Server band ho gaya ya koi error aaya. Upar ka message check karein.
pause
