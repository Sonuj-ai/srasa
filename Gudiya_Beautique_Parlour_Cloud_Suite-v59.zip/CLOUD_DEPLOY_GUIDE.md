# GUDIYA BEAUTIQUE PRO — CLOUD HOSTING GUIDE

Is package me `server.py` ko **Gunicorn / WSGI** ke saath cloud hosting ke liye ready kiya gaya hai, saath hi optional **`APP_PIN`** login protection bhi add kiya gaya hai taaki bahar internet se koi anjaan aapka billing ya cost data na dekh sake.

## 1. Cloud Par Deploy Kaise Karein (Render / Railway / VPS)
1. Is ZIP ko extract karke apni GitHub repository me push karein (ya cloud platform par upload karein).
2. Cloud service me `Procfile` aur `render.yaml` ke hisaab se start command chalega:
   `gunicorn server:app --bind 0.0.0.0:$PORT --workers 2 --threads 4`
3. **Environment Variables** set karein:
   - `APP_PIN`: Koi secret PIN/password set karein (example: `7860`) taaki bahar se open karne par PIN screen aaye.
   - `DB_PATH`, `BACKUP_DIR`, `IMAGES_DIR`: Persistent disk path set karein (agar disk attached hai) taaki restart ke baad data safe rahe.
4. Cloud se jo `https://...` link mile, use apne mobile ya laptop ke browser me kahin se bhi open karein aur **Add to Home Screen** kar lein.
