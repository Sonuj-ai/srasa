import os
import sys
import json
import csv
import io
import base64
import socket
import sqlite3
import threading
import webbrowser
from datetime import datetime
from urllib.parse import urlparse, parse_qs
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("DB_PATH", os.path.join(BASE_DIR, "gudiya_beautique_pro.db"))
BACKUP_DIR = os.environ.get("BACKUP_DIR", os.path.join(BASE_DIR, "backups"))
IMAGES_DIR = os.environ.get("IMAGES_DIR", os.path.join(BASE_DIR, "product_images"))
PORT = int(os.environ.get("PORT", 56672))

os.makedirs(BACKUP_DIR, exist_ok=True)
os.makedirs(IMAGES_DIR, exist_ok=True)


class ReusableThreadingHTTPServer(ThreadingHTTPServer):
    allow_reuse_address = True


def get_lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip or "192.168.0.101"
    except Exception:
        return "192.168.0.101"


def open_browser_later(url, delay=0.8):
    def _open():
        try:
            if os.name == "nt" and hasattr(os, "startfile"):
                os.startfile(url)
                return
        except Exception:
            pass
        try:
            webbrowser.open(url)
        except Exception:
            pass
    t = threading.Timer(delay, _open)
    t.daemon = True
    t.start()


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    os.makedirs(os.path.dirname(os.path.abspath(DB_PATH)), exist_ok=True)
    os.makedirs(BACKUP_DIR, exist_ok=True)
    os.makedirs(IMAGES_DIR, exist_ok=True)
    schema_file = os.path.join(BASE_DIR, "schema.sql")
    with open(schema_file, "r", encoding="utf-8") as f:
        schema = f.read()
    conn = get_db()
    cur = conn.cursor()
    cur.executescript(schema)

    cur.execute("PRAGMA table_info(sales)")
    s_cols = [r["name"] for r in cur.fetchall()]
    if "customer_mobile" not in s_cols:
        cur.execute("ALTER TABLE sales ADD COLUMN customer_mobile TEXT DEFAULT ''")
    if "paid_amount" not in s_cols:
        cur.execute("ALTER TABLE sales ADD COLUMN paid_amount REAL NOT NULL DEFAULT 0")
    if "due_amount" not in s_cols:
        cur.execute("ALTER TABLE sales ADD COLUMN due_amount REAL NOT NULL DEFAULT 0")

    cur.execute(
        """CREATE TABLE IF NOT EXISTS custom_visual_images (
            slot_key TEXT PRIMARY KEY,
            image_data TEXT NOT NULL DEFAULT '',
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )"""
    )
    cur.execute("PRAGMA table_info(purchases)")
    p_cols = [r["name"] for r in cur.fetchall()]
    if "paid_mode" not in p_cols:
        cur.execute("ALTER TABLE purchases ADD COLUMN paid_mode TEXT NOT NULL DEFAULT 'CASH'")
    if "purchase_type" not in p_cols:
        cur.execute("ALTER TABLE purchases ADD COLUMN purchase_type TEXT NOT NULL DEFAULT 'CASH'")

    cur.execute("SELECT COUNT(*) AS cnt FROM products")
    if cur.fetchone()["cnt"] == 0:
        seed_products = [
            ("OPTIC", "COSMETIC", "BAG SCHOOL [BLACK]", "", 12, 350.0, 530.0, "2027-12-31", 5),
            ("GB-101", "COSMETIC", "MATTE LIPSTICK RUBY", "", 25, 220.0, 450.0, "2027-08-15", 5),
            ("GB-102", "SKINCARE", "HYDRATING FACE SERUM", "", 15, 650.0, 1200.0, "2027-06-30", 4),
            ("GB-103", "JEWELLERY", "BRIDAL CHOKER SET", "", 8, 800.0, 1500.0, "", 3),
            ("GB-104", "POOJA BHANDAR", "PURE CAMPHOR PACK", "", 40, 90.0, 160.0, "2028-01-01", 10),
            ("GB-105", "STATIONERY", "GEL PEN BOX (12 PCS)", "", 30, 80.0, 140.0, "", 8),
        ]
        cur.executemany(
            """INSERT INTO products (barcode, category, name, image_data, qty, rate, mrp, expiry_date, reorder_level)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            seed_products,
        )

    cur.execute("SELECT COUNT(*) AS cnt FROM customers")
    if cur.fetchone()["cnt"] == 0:
        cur.executemany(
            "INSERT OR IGNORE INTO customers (name, phone) VALUES (?, ?)",
            [("WALK-IN", ""), ("GUDIYA REGULAR", ""), ("PRIYA SHARMA", "")],
        )

    cur.execute("SELECT COUNT(*) AS cnt FROM suppliers")
    if cur.fetchone()["cnt"] == 0:
        cur.executemany(
            "INSERT OR IGNORE INTO suppliers (name, phone) VALUES (?, ?)",
            [("MAIN WHOLESALE", ""), ("SHREE COSMETICS", ""), ("ROYAL DISTRIBUTORS", "")],
        )

    cur.execute("SELECT COUNT(*) AS cnt FROM sales")
    if cur.fetchone()["cnt"] == 0:
        cur.execute(
            """INSERT INTO sales (bill_no, counter_no, customer_name, category, barcode, product_name, qty, rate, mrp, discount_pct, net_amount, payment_mode)
               VALUES ('CM-1001', 'CN-1', 'WALK-IN', 'COSMETIC', 'OPTIC', 'BAG SCHOOL [BLACK]', 1, 350.0, 530.0, 0, 530.0, 'CASH')"""
        )

    cur.execute("SELECT COUNT(*) AS cnt FROM purchases")
    if cur.fetchone()["cnt"] == 0:
        cur.execute(
            """INSERT INTO purchases (voucher_no, purchase_type, supplier_name, barcode, category, product_name, qty, rate, mrp, total_amount, paid_amount, paid_mode, due_amount)
               VALUES ('PV-101', 'CASH', 'MAIN WHOLESALE', 'OPTIC', 'COSMETIC', 'BAG SCHOOL [BLACK]', 5, 230.0, 530.0, 1150.0, 1150.0, 'CASH', 0.0)"""
        )


    extra_seed = [
        ("SRV-16", "WAXING", "BIKINI / UNDERARM WAXING", 300.0, 20),
        ("SRV-17", "CLEANUP", "D-TAN CLEANUP", 550.0, 35),
        ("SRV-18", "FACE MASSAGE", "AYURVEDIC FACE & NECK MASSAGE", 450.0, 30),
        ("SRV-19", "HAIR CARE", "HAIR STRAIGHTENING / SMOOTHENING", 3500.0, 120),
        ("SRV-20", "HAIR CARE", "HAIR COLOUR / ROOT TOUCH-UP", 900.0, 60),
        ("SRV-21", "MANI-PEDI", "SPA PEDICURE", 650.0, 45),
        ("SRV-22", "THREADING", "FULL FACE THREADING", 250.0, 25),
        ("SRV-23", "MAKEUP", "ENGAGEMENT MAKEUP", 4500.0, 90),
        ("SRV-24", "MEHNDI", "HAND & FOOT MEHNDI", 600.0, 45),
        ("SRV-25", "PARLOUR PACKAGE", "COMPLETE BRIDAL / FESTIVAL PACKAGE", 6500.0, 180),
    ]
    cur.executemany(
        """INSERT OR IGNORE INTO services (code, category, name, charge, duration_min)
           VALUES (?, ?, ?, ?, ?)""",
        extra_seed,
    )

    cur.execute("SELECT COUNT(*) AS cnt FROM services")
    if cur.fetchone()["cnt"] == 0:
        seed_services = [
            ("SRV-01", "FACIAL", "FRUIT FACIAL", 600.0, 45),
            ("SRV-02", "FACIAL", "GOLD / DIAMOND FACIAL", 1200.0, 60),
            ("SRV-03", "FACIAL", "DE-TAN / BRIGHTENING FACIAL", 800.0, 45),
            ("SRV-04", "CLEANUP", "SKIN CLEANUP", 450.0, 30),
            ("SRV-05", "WAXING", "FULL ARMS & LEGS WAXING", 700.0, 45),
            ("SRV-06", "WAXING", "RICA / CHOCOLATE WAXING", 950.0, 45),
            ("SRV-07", "FACE MASSAGE", "RELAXING FACE MASSAGE", 350.0, 25),
            ("SRV-08", "THREADING", "EYEBROW & UPPER LIP THREADING", 100.0, 15),
            ("SRV-09", "HAIR CARE", "HAIR SPA & STEAM", 850.0, 45),
            ("SRV-10", "HAIR CARE", "HAIR CUT & STYLING", 300.0, 30),
            ("SRV-11", "MANI-PEDI", "MANICURE & PEDICURE", 900.0, 60),
            ("SRV-12", "BLEACH", "FACE & NECK BLEACH / DE-TAN", 350.0, 25),
            ("SRV-13", "MAKEUP", "PARTY MAKEUP", 2500.0, 75),
            ("SRV-14", "MAKEUP", "BRIDAL MAKEUP PACKAGE", 12000.0, 180),
            ("SRV-15", "MEHNDI", "BRIDAL / FESTIVAL MEHNDI", 1500.0, 90),
            ("SRV-16", "WAXING", "BIKINI / UNDERARM WAXING", 300.0, 20),
            ("SRV-17", "CLEANUP", "D-TAN CLEANUP", 550.0, 35),
            ("SRV-18", "FACE MASSAGE", "AYURVEDIC FACE & NECK MASSAGE", 450.0, 30),
            ("SRV-19", "HAIR CARE", "HAIR STRAIGHTENING / SMOOTHENING", 3500.0, 120),
            ("SRV-20", "HAIR CARE", "HAIR COLOUR / ROOT TOUCH-UP", 900.0, 60),
            ("SRV-21", "MANI-PEDI", "SPA PEDICURE", 650.0, 45),
            ("SRV-22", "THREADING", "FULL FACE THREADING", 250.0, 25),
            ("SRV-23", "MAKEUP", "ENGAGEMENT MAKEUP", 4500.0, 90),
            ("SRV-24", "MEHNDI", "HAND & FOOT MEHNDI", 600.0, 45),
            ("SRV-25", "PARLOUR PACKAGE", "COMPLETE BRIDAL / FESTIVAL PACKAGE", 6500.0, 180),
        ]
        cur.executemany(
            """INSERT INTO services (code, category, name, charge, duration_min)
               VALUES (?, ?, ?, ?, ?)""",
            seed_services,
        )

    conn.commit()
    conn.close()


def save_product_image_file(barcode, image_data):
    if not image_data or not image_data.startswith("data:image/"):
        return image_data
    try:
        header, b64 = image_data.split(",", 1)
        ext = "png"
        if "jpeg" in header or "jpg" in header:
            ext = "jpg"
        elif "webp" in header:
            ext = "webp"
        raw_bytes = base64.b64decode(b64)
        safe_code = "".join(c for c in barcode if c.isalnum() or c in ("-", "_")) or "ITEM"
        img_name = f"{safe_code}.{ext}"
        img_path = os.path.join(IMAGES_DIR, img_name)
        with open(img_path, "wb") as f:
            f.write(raw_bytes)
        return f"/product_images/{img_name}"
    except Exception:
        return image_data


def get_next_cash_memo_no(cur):
    cur.execute("SELECT COUNT(DISTINCT bill_no) AS cnt FROM sales")
    cnt = int((cur.fetchone() or {})["cnt"] or 0)
    return f"CM-{1001 + cnt}"



def api_get_services():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM services ORDER BY id ASC")
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def api_delete_service(data):
    code = (data.get("code") or "").strip().upper()
    if not code:
        return {"error": "SERVICE CODE REQUIRED"}, 400
    conn = get_db()
    cur = conn.cursor()
    cur.execute("DELETE FROM services WHERE UPPER(code) = ?", (code,))
    conn.commit()
    conn.close()
    return {"status": "DELETED", "code": code}, 200


def api_save_service(data):
    code = (data.get("code") or "").strip().upper()
    original_code = (data.get("original_code") or "").strip().upper()
    category = (data.get("category") or "PARLOUR").strip().upper()
    name = (data.get("name") or "").strip().upper()
    charge = float(data.get("charge") or 0)
    duration_min = int(float(data.get("duration_min") or 30))

    if not name:
        return {"error": "SERVICE NAME REQUIRED"}, 400
    if not code:
        code = f"SRV-{datetime.now().strftime('%H%M%S%f')[-6:]}"

    conn = get_db()
    cur = conn.cursor()
    lookup = original_code or code
    cur.execute("SELECT id FROM services WHERE UPPER(code) = ?", (lookup,))
    existing = cur.fetchone()
    if existing:
        cur.execute(
            """UPDATE services
               SET code=?, category=?, name=?, charge=?, duration_min=?, updated_at=CURRENT_TIMESTAMP
               WHERE id=?""",
            (code, category, name, charge, duration_min, existing["id"]),
        )
    else:
        cur.execute(
            """INSERT INTO services (code, category, name, charge, duration_min)
               VALUES (?, ?, ?, ?, ?)""",
            (code, category, name, charge, duration_min),
        )
    conn.commit()
    conn.close()
    return {"status": "SAVED", "code": code, "name": name, "category": category, "charge": charge, "duration_min": duration_min}, 200



def api_get_custom_images():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT slot_key, image_data FROM custom_visual_images")
    rows = cur.fetchall()
    conn.close()
    return {"images": {r["slot_key"]: r["image_data"] for r in rows if r["image_data"]}}, 200


def api_save_custom_image(data):
    slot_key = (data.get("slot_key") or "").strip()
    image_data = (data.get("image_data") or "").strip()
    if not slot_key:
        return {"error": "SLOT KEY REQUIRED"}, 400
    conn = get_db()
    cur = conn.cursor()
    if image_data:
        cur.execute(
            """INSERT INTO custom_visual_images (slot_key, image_data, updated_at)
               VALUES (?, ?, CURRENT_TIMESTAMP)
               ON CONFLICT(slot_key) DO UPDATE SET image_data = excluded.image_data, updated_at = CURRENT_TIMESTAMP""",
            (slot_key, image_data),
        )
    else:
        cur.execute("DELETE FROM custom_visual_images WHERE slot_key = ?", (slot_key,))
    conn.commit()
    conn.close()
    return {"status": "SAVED", "slot_key": slot_key}, 200

def api_get_state(show_cost=True):
    conn = get_db()
    cur = conn.cursor()

    cur.execute("SELECT * FROM products ORDER BY id ASC")
    products = []
    categories_set = {"COSMETIC", "SKINCARE", "JEWELLERY", "POOJA BHANDAR", "STATIONERY"}
    for r in cur.fetchall():
        d = dict(r)
        if d.get("category"):
            categories_set.add(str(d["category"]).strip().upper())
        if not show_cost:
            d["rate"] = None
        products.append(d)

    cur.execute("SELECT name FROM customers ORDER BY name ASC")
    customers = [r["name"] for r in cur.fetchall()]

    cur.execute("SELECT name FROM suppliers ORDER BY name ASC")
    suppliers = [r["name"] for r in cur.fetchall()]

    cur.execute("SELECT COALESCE(SUM(net_amount), 0) AS net_sale, COUNT(DISTINCT bill_no) AS inv_count FROM sales")
    s_row = cur.fetchone()
    today_net_sale = float(s_row["net_sale"] or 0)
    invoices_today = int(s_row["inv_count"] or 0)

    cur.execute("SELECT COALESCE(SUM(qty * rate), 0) AS cost_val, COALESCE(SUM(qty * mrp), 0) AS mrp_val FROM products")
    inv_row = cur.fetchone()
    stock_cost_val = float(inv_row["cost_val"] or 0)
    stock_mrp_val = float(inv_row["mrp_val"] or 0)

    cur.execute("SELECT COALESCE(SUM(due_amount), 0) AS pending_dues, COALESCE(SUM(total_amount), 0) AS total_pur FROM purchases")
    p_row = cur.fetchone()
    pending_dues = float(p_row["pending_dues"] or 0)
    total_pur = float(p_row["total_pur"] or 0)

    cur.execute("SELECT COUNT(*) AS alert_cnt FROM products WHERE qty <= reorder_level")
    alerts = int(cur.fetchone()["alert_cnt"] or 0)

    cur.execute("SELECT COALESCE(SUM((mrp - rate) * qty), 0) AS est_profit FROM sales")
    est_profit = float(cur.fetchone()["est_profit"] or 0)

    cur.execute("SELECT * FROM sales ORDER BY id DESC LIMIT 300")
    sales_list = [dict(r) for r in cur.fetchall()]

    cur.execute("SELECT * FROM purchases ORDER BY id DESC LIMIT 300")
    purchases_list = []
    for r in cur.fetchall():
        pd = dict(r)
        if not show_cost:
            pd["rate"] = None
            pd["total_amount"] = None
            pd["paid_amount"] = None
            pd["due_amount"] = None
        purchases_list.append(pd)

    cur.execute("SELECT * FROM services ORDER BY id ASC")
    services_list = [dict(r) for r in cur.fetchall()]
    cur.execute(
        """SELECT bill_no,
                  MAX(customer_name) AS customer_name,
                  MAX(customer_mobile) AS customer_mobile,
                  MAX(created_at) AS created_at,
                  GROUP_CONCAT(product_name, ', ') AS services_summary,
                  COALESCE(SUM(net_amount), 0) AS total_amount,
                  COALESCE(SUM(paid_amount), 0) AS paid_amount,
                  COALESCE(SUM(due_amount), 0) AS due_amount
           FROM sales
           GROUP BY bill_no
           HAVING COALESCE(SUM(due_amount), 0) > 0
           ORDER BY MAX(id) DESC"""
    )
    customer_dues_list = [dict(r) for r in cur.fetchall()]
    total_customer_due = round(sum(float(x["due_amount"] or 0) for x in customer_dues_list), 2)

    next_cash_memo = get_next_cash_memo_no(cur)
    conn.close()

    return {
        "lan_ip": get_lan_ip(),
        "port": PORT,
        "pid": os.getpid(),
        "base_dir": BASE_DIR,
        "next_cash_memo": next_cash_memo,
        "kpis": {
            "today_net_sale": today_net_sale,
            "invoices_today": invoices_today,
            "stock_value": stock_cost_val,
            "stock_mrp_value": stock_mrp_val,
            "pending_supplier_dues": pending_dues,
            "total_purchases": total_pur,
            "alerts_count": alerts,
            "est_gross_profit": est_profit,
            "pending_customer_dues": total_customer_due,
            "pending_customer_count": len(customer_dues_list),
        },
        "customer_dues": customer_dues_list,
        "custom_images": {r["slot_key"]: r["image_data"] for r in cur.execute("SELECT slot_key, image_data FROM custom_visual_images").fetchall() if r["image_data"]},
        "products": products,
        "categories": sorted(categories_set),
        "customers": customers,
        "suppliers": suppliers,
        "services": services_list,
        "sales": sales_list,
        "purchases": purchases_list,
    }


def api_save_product(data):
    barcode = (data.get("barcode") or "").strip().upper()
    original_barcode = (data.get("original_barcode") or "").strip().upper()
    category = (data.get("category") or "COSMETIC").strip().upper()
    name = (data.get("name") or "").strip().upper()
    raw_img = (data.get("image_data") or "").strip()
    qty = int(float(data.get("qty") or 0))
    rate = float(data.get("rate") or 0)
    mrp = float(data.get("mrp") or 0)
    expiry_date = (data.get("expiry_date") or "").strip()
    reorder_level = int(float(data.get("reorder_level") or 5))

    if not name:
        return {"error": "PRODUCT NAME REQUIRED"}, 400
    if not barcode:
        barcode = f"NB-{datetime.now().strftime('%H%M%S%f')[-8:]}"

    image_data = save_product_image_file(barcode, raw_img)

    conn = get_db()
    cur = conn.cursor()

    target_lookup = original_barcode or barcode
    cur.execute("SELECT id, barcode, image_data FROM products WHERE UPPER(barcode) = ?", (target_lookup,))
    existing = cur.fetchone()

    if existing:
        final_img = image_data if raw_img else (existing["image_data"] or "")
        cur.execute(
            """UPDATE products
               SET barcode=?, category=?, name=?, image_data=?, qty=?, rate=?, mrp=?, expiry_date=?, reorder_level=?, updated_at=CURRENT_TIMESTAMP
               WHERE id=?""",
            (barcode, category, name, final_img, qty, rate, mrp, expiry_date, reorder_level, existing["id"]),
        )
        if existing["barcode"].upper() != barcode:
            cur.execute("UPDATE sales SET barcode=?, product_name=?, category=? WHERE UPPER(barcode)=?", (barcode, name, category, existing["barcode"].upper()))
        else:
            cur.execute("UPDATE sales SET product_name=?, category=? WHERE UPPER(barcode)=?", (name, category, barcode))
    else:
        cur.execute(
            """INSERT INTO products (barcode, category, name, image_data, qty, rate, mrp, expiry_date, reorder_level)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (barcode, category, name, image_data, qty, rate, mrp, expiry_date, reorder_level),
        )
    conn.commit()
    conn.close()
    return {"status": "SAVED", "barcode": barcode, "name": name, "category": category}, 200


def api_save_customer(data):
    name = (data.get("name") or "").strip().upper()
    old_name = (data.get("old_name") or "").strip().upper()
    if not name:
        return {"error": "CUSTOMER NAME REQUIRED"}, 400
    conn = get_db()
    cur = conn.cursor()
    if old_name and old_name != name:
        cur.execute("UPDATE customers SET name=?, updated_at=CURRENT_TIMESTAMP WHERE UPPER(name)=?", (name, old_name))
        if cur.rowcount == 0:
            cur.execute("INSERT OR IGNORE INTO customers (name) VALUES (?)", (name,))
        cur.execute("UPDATE sales SET customer_name=? WHERE UPPER(customer_name)=?", (name, old_name))
    else:
        cur.execute("INSERT OR IGNORE INTO customers (name) VALUES (?)", (name,))
    conn.commit()
    conn.close()
    return {"status": "SAVED", "customer_name": name}, 200


def api_save_supplier(data):
    name = (data.get("name") or "").strip().upper()
    old_name = (data.get("old_name") or "").strip().upper()
    if not name:
        return {"error": "SUPPLIER NAME REQUIRED"}, 400
    conn = get_db()
    cur = conn.cursor()
    if old_name and old_name != name:
        cur.execute("UPDATE suppliers SET name=?, updated_at=CURRENT_TIMESTAMP WHERE UPPER(name)=?", (name, old_name))
        if cur.rowcount == 0:
            cur.execute("INSERT OR IGNORE INTO suppliers (name) VALUES (?)", (name,))
        cur.execute("UPDATE purchases SET supplier_name=? WHERE UPPER(supplier_name)=?", (name, old_name))
    else:
        cur.execute("INSERT OR IGNORE INTO suppliers (name) VALUES (?)", (name,))
    conn.commit()
    conn.close()
    return {"status": "SAVED", "supplier_name": name}, 200


def api_create_sale(data):
    counter_no = (data.get("counter_no") or "CN-1").strip().upper()
    customer_name = (data.get("customer_name") or "WALK-IN").strip().upper()
    customer_mobile = (data.get("customer_mobile") or "").strip()
    payment_mode = (data.get("payment_mode") or "CASH").strip().upper()
    items = data.get("items") or []

    if not items:
        return {"error": "CART IS EMPTY"}, 400

    conn = get_db()
    cur = conn.cursor()
    cur.execute("INSERT OR IGNORE INTO customers (name, phone) VALUES (?, ?)", (customer_name, customer_mobile))
    if customer_mobile:
        cur.execute("UPDATE customers SET phone = ? WHERE UPPER(name) = ?", (customer_mobile, customer_name))

    raw_bill_no = (data.get("bill_no") or "").strip().upper()
    bill_no = raw_bill_no if raw_bill_no else get_next_cash_memo_no(cur)

    prepared = []
    total_bill = 0.0
    for it in items:
        barcode = (it.get("barcode") or "").strip().upper() or "NO-BARCODE"
        name = (it.get("product_name") or "").strip().upper()
        category = (it.get("category") or "COSMETIC").strip().upper()
        qty = int(float(it.get("qty") or 1))
        mrp = float(it.get("mrp") or 0)
        disc_pct = float(it.get("discount_pct") or 0)
        gross = qty * mrp
        net_amt = round(gross - (gross * disc_pct / 100.0), 2)
        total_bill = round(total_bill + net_amt, 2)
        prepared.append((barcode, name, category, qty, mrp, disc_pct, net_amt, it.get("rate")))

    raw_paid = data.get("paid_amount")
    if raw_paid is None or str(raw_paid).strip() == "":
        paid_total = total_bill
    else:
        paid_total = round(max(0.0, float(raw_paid)), 2)
    if paid_total > total_bill:
        paid_total = total_bill
    due_total = round(max(0.0, total_bill - paid_total), 2)

    remaining_paid = paid_total
    for idx, (barcode, name, category, qty, mrp, disc_pct, net_amt, it_rate) in enumerate(prepared):
        if idx == len(prepared) - 1:
            line_paid = round(min(net_amt, max(0.0, remaining_paid)), 2)
        else:
            line_paid = round(min(net_amt, remaining_paid), 2)
            remaining_paid = round(remaining_paid - line_paid, 2)
        line_due = round(max(0.0, net_amt - line_paid), 2)

        cur.execute("SELECT id, qty, rate FROM products WHERE UPPER(barcode) = ? OR UPPER(name) = ?", (barcode, name))
        prod = cur.fetchone()
        prod_rate = float(it_rate) if it_rate is not None else (float(prod["rate"]) if prod else round(mrp * 0.65, 2))

        cur.execute(
            """INSERT INTO sales (bill_no, counter_no, customer_name, customer_mobile, category, barcode, product_name, qty, rate, mrp, discount_pct, net_amount, paid_amount, due_amount, payment_mode)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (bill_no, counter_no, customer_name, customer_mobile, category, barcode, name or "ITEM", qty, prod_rate, mrp, disc_pct, net_amt, line_paid, line_due, payment_mode),
        )

        if prod:
            new_qty = max(0, int(prod["qty"]) - qty)
            cur.execute("UPDATE products SET qty=?, updated_at=CURRENT_TIMESTAMP WHERE id=?", (new_qty, prod["id"]))

    conn.commit()
    conn.close()
    return {
        "status": "SAVED",
        "bill_no": bill_no,
        "cash_memo_no": bill_no,
        "total": total_bill,
        "paid_amount": paid_total,
        "due_amount": due_total,
    }, 200


def api_pay_sale_due(data):
    bill_no = (data.get("bill_no") or "").strip().upper()
    if not bill_no:
        return {"error": "BILL NO REQUIRED"}, 400
    try:
        pay_amt = float(data.get("pay_amount") or 0)
    except ValueError:
        return {"error": "VALID PAID AMOUNT REQUIRED"}, 400
    if pay_amt <= 0:
        return {"error": "POSITIVE PAID AMOUNT REQUIRED"}, 400

    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT id, paid_amount, due_amount FROM sales WHERE UPPER(bill_no) = ? AND due_amount > 0 ORDER BY id ASC", (bill_no,))
    rows = cur.fetchall()
    if not rows:
        conn.close()
        return {"error": "NO PENDING CUSTOMER DUE FOUND FOR THIS BILL"}, 404

    rem = pay_amt
    for r in rows:
        if rem <= 0:
            break
        d_amt = float(r["due_amount"] or 0)
        p_amt = float(r["paid_amount"] or 0)
        apply_amt = min(d_amt, rem)
        new_due = round(max(0.0, d_amt - apply_amt), 2)
        new_paid = round(p_amt + apply_amt, 2)
        rem = round(rem - apply_amt, 2)
        cur.execute("UPDATE sales SET paid_amount = ?, due_amount = ? WHERE id = ?", (new_paid, new_due, r["id"]))

    cur.execute("SELECT COALESCE(SUM(due_amount), 0) AS rem_due FROM sales WHERE UPPER(bill_no) = ?", (bill_no,))
    rem_due = float((cur.fetchone() or {})["rem_due"] or 0)
    conn.commit()
    conn.close()
    return {"status": "PAID", "bill_no": bill_no, "remaining_due": rem_due}, 200


def api_create_purchase(data):
    purchase_type = (data.get("purchase_type") or "CASH").strip().upper()
    if purchase_type not in ("CASH", "CREDIT"):
        purchase_type = "CASH"
    voucher_no = (data.get("voucher_no") or f"PV-{datetime.now().strftime('%H%M%S')}").strip().upper()
    supplier_name = (data.get("supplier_name") or "SUPPLIER").strip().upper()
    barcode = (data.get("barcode") or "").strip().upper()
    category = (data.get("category") or "COSMETIC").strip().upper()
    product_name = (data.get("product_name") or "").strip().upper()
    qty = int(float(data.get("qty") or 0))
    rate = float(data.get("rate") or 0)
    mrp = float(data.get("mrp") or 0)
    raw_paid = (str(data.get("paid_amount") or "")).strip().upper()
    paid_mode = "CASH"
    for mode_opt in ("CASH", "UPI", "CARD"):
        if mode_opt in raw_paid:
            paid_mode = mode_opt
            break
    try:
        entered_paid = float(raw_paid) if raw_paid else None
    except ValueError:
        entered_paid = None

    if qty <= 0:
        return {"error": "POSITIVE QTY REQUIRED"}, 400
    if not barcode:
        barcode = f"NB-{datetime.now().strftime('%H%M%S')}"

    total_amount = round(qty * rate, 2)
    if purchase_type == "CREDIT":
        paid_amount = 0.0
        due_amount = total_amount
    else:
        paid_amount = total_amount if entered_paid is None else round(max(0.0, entered_paid), 2)
        due_amount = round(max(0.0, total_amount - paid_amount), 2)

    conn = get_db()
    cur = conn.cursor()
    cur.execute("INSERT OR IGNORE INTO suppliers (name) VALUES (?)", (supplier_name,))

    cur.execute("SELECT id, name, category, mrp FROM products WHERE UPPER(barcode) = ?", (barcode,))
    prod = cur.fetchone()

    final_name = product_name or (prod["name"] if prod else barcode)
    final_cat = category or (prod["category"] if prod else "COSMETIC")
    final_mrp = mrp if mrp > 0 else (float(prod["mrp"]) if prod else rate)

    cur.execute(
        """INSERT INTO purchases (voucher_no, purchase_type, supplier_name, barcode, category, product_name, qty, rate, mrp, total_amount, paid_amount, paid_mode, due_amount)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (voucher_no, purchase_type, supplier_name, barcode, final_cat, final_name, qty, rate, final_mrp, total_amount, paid_amount, paid_mode, due_amount),
    )

    if prod:
        cur.execute(
            """UPDATE products SET qty = qty + ?, rate = ?, mrp = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?""",
            (qty, rate, final_mrp, prod["id"]),
        )
    else:
        cur.execute(
            """INSERT INTO products (barcode, category, name, image_data, qty, rate, mrp)
               VALUES (?, ?, ?, '', ?, ?, ?)""",
            (barcode, final_cat, final_name, qty, rate, final_mrp),
        )

    conn.commit()
    conn.close()
    return {"status": "SAVED", "voucher_no": voucher_no, "purchase_type": purchase_type, "total_amount": total_amount, "paid_amount": paid_amount, "due_amount": due_amount}, 200


def api_pay_purchase_due(data):
    pur_id = data.get("id")
    if pur_id is None:
        return {"error": "PURCHASE ID REQUIRED"}, 400
    raw_pay = str(data.get("pay_amount") or "").strip()
    pay_mode = (data.get("pay_mode") or "CASH").strip().upper()
    try:
        pay_amt = float(raw_pay)
    except ValueError:
        return {"error": "VALID PAID AMOUNT REQUIRED"}, 400
    if pay_amt <= 0:
        return {"error": "POSITIVE PAID AMOUNT REQUIRED"}, 400

    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT id, voucher_no, paid_amount, due_amount FROM purchases WHERE id = ?", (pur_id,))
    row = cur.fetchone()
    if not row:
        conn.close()
        return {"error": "PURCHASE BILL NOT FOUND"}, 404

    cur_due = float(row["due_amount"] or 0)
    cur_paid = float(row["paid_amount"] or 0)
    applied = min(cur_due, pay_amt)
    new_due = round(max(0.0, cur_due - applied), 2)
    new_paid = round(cur_paid + applied, 2)

    cur.execute(
        "UPDATE purchases SET paid_amount = ?, due_amount = ?, paid_mode = ? WHERE id = ?",
        (new_paid, new_due, pay_mode, pur_id),
    )
    conn.commit()
    conn.close()
    return {"status": "PAID", "id": pur_id, "voucher_no": row["voucher_no"], "paid_amount": new_paid, "due_amount": new_due}, 200


def api_delete_purchase(data):
    pur_id = data.get("id")
    if pur_id is None:
        return {"error": "PURCHASE ID REQUIRED"}, 400
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT id, voucher_no, barcode, product_name, qty FROM purchases WHERE id = ?", (pur_id,))
    row = cur.fetchone()
    if not row:
        conn.close()
        return {"error": "PURCHASE BILL NOT FOUND"}, 404

    qty_to_revert = int(row["qty"] or 0)
    bcode = (row["barcode"] or "").strip().upper()
    pname = (row["product_name"] or "").strip().upper()

    cur.execute("SELECT id, qty FROM products WHERE UPPER(barcode) = ? OR UPPER(name) = ?", (bcode, pname))
    prod = cur.fetchone()
    if prod and qty_to_revert > 0:
        new_qty = max(0, int(prod["qty"] or 0) - qty_to_revert)
        cur.execute("UPDATE products SET qty = ?, updated_at=CURRENT_TIMESTAMP WHERE id=?", (new_qty, prod["id"]))

    cur.execute("DELETE FROM purchases WHERE id = ?", (pur_id,))
    conn.commit()
    conn.close()
    return {"status": "REMOVED", "id": pur_id, "voucher_no": row["voucher_no"]}, 200


def build_stock_csv():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT barcode, category, name, qty, rate, mrp, expiry_date FROM products ORDER BY id ASC")
    rows = cur.fetchall()
    conn.close()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["BARCODE", "CATEGORY", "PRODUCT NAME", "QTY", "RATE", "MRP", "EXPIRY DATE"])
    for r in rows:
        writer.writerow([r["barcode"], r["category"], r["name"], r["qty"], r["rate"], r["mrp"], r["expiry_date"]])
    return output.getvalue()


def build_sales_csv():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT bill_no, counter_no, customer_name, category, barcode, product_name, qty, mrp, discount_pct, net_amount, payment_mode, created_at FROM sales ORDER BY id DESC")
    rows = cur.fetchall()
    conn.close()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["CASH MEMO NO", "COUNTER", "CUSTOMER", "CATEGORY", "BARCODE", "PRODUCT NAME", "QTY", "MRP", "DISCOUNT %", "NET AMOUNT", "PAYMENT", "DATE"])
    for r in rows:
        writer.writerow([r["bill_no"], r["counter_no"], r["customer_name"], r["category"], r["barcode"], r["product_name"], r["qty"], r["mrp"], r["discount_pct"], r["net_amount"], r["payment_mode"], r["created_at"]])
    return output.getvalue()


def api_create_backup():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM products")
    products = [dict(r) for r in cur.fetchall()]
    cur.execute("SELECT * FROM sales")
    sales = [dict(r) for r in cur.fetchall()]
    cur.execute("SELECT * FROM purchases")
    purchases = [dict(r) for r in cur.fetchall()]
    conn.close()
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    fname = f"gudiya_backup_{ts}.json"
    fpath = os.path.join(BACKUP_DIR, fname)
    with open(fpath, "w", encoding="utf-8") as f:
        json.dump({"exported_at": ts, "products": products, "sales": sales, "purchases": purchases}, f, indent=2)
    return {"status": "BACKUP CREATED", "file": fname}, 200


APP_PIN = os.environ.get("APP_PIN", "").strip()


def wsgi_app(environ, start_response):
    init_db()
    method = environ.get("REQUEST_METHOD", "GET").upper()
    path = environ.get("PATH_INFO", "/")
    query_string = environ.get("QUERY_STRING", "")
    full_path = f"{path}?{query_string}" if query_string else path

    if APP_PIN:
        cookie_hdr = environ.get("HTTP_COOKIE", "")
        auth_ok = False
        for part in cookie_hdr.split(";"):
            k, _, v = part.strip().partition("=")
            if k == "gb_pin" and v == APP_PIN:
                auth_ok = True
                break
        if path == "/api/login" and method == "POST":
            length = int(environ.get("CONTENT_LENGTH") or "0")
            raw = environ["wsgi.input"].read(length).decode("utf-8") if length > 0 else "{}"
            payload = json.loads(raw or "{}")
            entered = str(payload.get("pin", "")).strip()
            if entered == APP_PIN:
                body = json.dumps({"status": "OK"}).encode("utf-8")
                start_response("200 OK", [
                    ("Content-Type", "application/json"),
                    ("Content-Length", str(len(body))),
                    ("Set-Cookie", f"gb_pin={APP_PIN}; Path=/; HttpOnly; SameSite=Lax"),
                ])
                return [body]
            body = json.dumps({"error": "INVALID PIN"}).encode("utf-8")
            start_response("401 Unauthorized", [
                ("Content-Type", "application/json"),
                ("Content-Length", str(len(body))),
            ])
            return [body]
        if not auth_ok and path != "/health":
            login_html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>GUDIYA BEAUTIQUE - LOGIN</title>
<style>
  body {{ margin:0; font-family:"Segoe UI",Arial,sans-serif; background:#FDECEF; display:flex; align-items:center; justify-content:center; min-height:100vh; }}
  .box {{ background:#fff; border:2px solid #6E0D25; border-radius:12px; padding:28px; width:340px; text-align:center; }}
  h2 {{ margin:0 0 6px; color:#6E0D25; }}
  p {{ margin:0 0 16px; font-size:12px; color:#555; font-weight:700; }}
  input {{ width:100%; padding:10px; font-size:16px; text-align:center; border:1px solid #D4B5BD; border-radius:8px; margin-bottom:12px; box-sizing:border-box; font-weight:800; }}
  button {{ width:100%; padding:10px; background:#6E0D25; color:#fff; border:none; border-radius:8px; font-weight:800; cursor:pointer; }}
  .err {{ color:#BE123C; font-size:12px; font-weight:800; margin-top:8px; }}
</style>
</head>
<body>
  <div class="box">
    <h2>GUDIYA BEAUTIQUE</h2>
    <p>CLOUD ACCESS PIN REQUIRED</p>
    <input id="pinInput" type="password" placeholder="ENTER ACCESS PIN" onkeydown="if(event.key==='Enter') doLogin()" />
    <button onclick="doLogin()">UNLOCK SOFTWARE</button>
    <div class="err" id="errMsg"></div>
  </div>
<script>
async function doLogin() {{
  const pin = document.getElementById("pinInput").value;
  const res = await fetch("/api/login", {{ method:"POST", headers:{{"Content-Type":"application/json"}}, body:JSON.stringify({{pin}}) }});
  if (res.ok) {{ location.reload(); }} else {{ document.getElementById("errMsg").textContent = "WRONG PIN! TRY AGAIN."; }}
}}
</script>
</body>
</html>""".encode("utf-8")
            start_response("200 OK", [
                ("Content-Type", "text/html; charset=utf-8"),
                ("Content-Length", str(len(login_html))),
            ])
            return [login_html]

    parsed = urlparse(full_path)
    p = parsed.path
    qs = parse_qs(parsed.query)

    if p == "/health":
        body = b'{"status":"ok"}'
        start_response("200 OK", [("Content-Type", "application/json"), ("Content-Length", str(len(body)))])
        return [body]
    elif p in ("/", "/pro_ui.html"):
        with open(os.path.join(BASE_DIR, "pro_ui.html"), "rb") as f:
            body = f.read()
        start_response("200 OK", [("Content-Type", "text/html; charset=utf-8"), ("Content-Length", str(len(body)))])
        return [body]
    elif p == "/manifest.json":
        with open(os.path.join(BASE_DIR, "manifest.json"), "rb") as f:
            body = f.read()
        start_response("200 OK", [("Content-Type", "application/json"), ("Content-Length", str(len(body)))])
        return [body]
    elif p == "/sw.js":
        with open(os.path.join(BASE_DIR, "sw.js"), "rb") as f:
            body = f.read()
        start_response("200 OK", [("Content-Type", "application/javascript"), ("Content-Length", str(len(body)))])
        return [body]
    elif p.startswith("/product_images/"):
        rel_name = os.path.basename(p)
        img_path = os.path.join(IMAGES_DIR, rel_name)
        if os.path.isfile(img_path):
            ext = os.path.splitext(rel_name)[1].lower()
            ctype = "image/jpeg" if ext in (".jpg", ".jpeg") else ("image/webp" if ext == ".webp" else "image/png")
            with open(img_path, "rb") as f:
                body = f.read()
            start_response("200 OK", [("Content-Type", ctype), ("Content-Length", str(len(body)))])
            return [body]
        start_response("404 Not Found", [("Content-Type", "text/plain")])
        return [b"NOT FOUND"]
    elif p == "/api/state":
        show_cost = (qs.get("show_cost", ["1"])[0] == "1")
        body = json.dumps(api_get_state(show_cost)).encode("utf-8")
        start_response("200 OK", [("Content-Type", "application/json"), ("Content-Length", str(len(body)))])
        return [body]
    elif p == "/api/custom-images":
        res, code = api_get_custom_images()
        body = json.dumps(res).encode("utf-8")
        start_response("200 OK" if code == 200 else f"{code} Error", [("Content-Type", "application/json"), ("Content-Length", str(len(body)))])
        return [body]
    elif p == "/api/export/stock.csv":
        body = build_stock_csv().encode("utf-8")
        start_response("200 OK", [("Content-Type", "text/csv"), ("Content-Disposition", "attachment; filename=gudiya_beautique_stock.csv"), ("Content-Length", str(len(body)))])
        return [body]
    elif p == "/api/export/sales.csv":
        body = build_sales_csv().encode("utf-8")
        start_response("200 OK", [("Content-Type", "text/csv"), ("Content-Disposition", "attachment; filename=gudiya_beautique_sales.csv"), ("Content-Length", str(len(body)))])
        return [body]
    elif method == "POST":
        length = int(environ.get("CONTENT_LENGTH") or "0")
        raw = environ["wsgi.input"].read(length).decode("utf-8") if length > 0 else "{}"
        data = json.loads(raw or "{}")
        if p == "/api/products":
            res, code = api_save_product(data)
        elif p == "/api/customers":
            res, code = api_save_customer(data)
        elif p == "/api/suppliers":
            res, code = api_save_supplier(data)
        elif p == "/api/sale":
            res, code = api_create_sale(data)
        elif p == "/api/sale/pay":
            res, code = api_pay_sale_due(data)
        elif p == "/api/purchase":
            res, code = api_create_purchase(data)
        elif p == "/api/purchase/pay":
            res, code = api_pay_purchase_due(data)
        elif p == "/api/purchase/delete":
            res, code = api_delete_purchase(data)
        elif p == "/api/backup":
            res, code = api_create_backup()
        elif p == "/api/custom-images":
            res, code = api_save_custom_image(data)
        elif p == "/api/services":
            res, code = api_save_service(data)
        elif p == "/api/services/delete":
            res, code = api_delete_service(data)
        else:
            res, code = {"error": "NOT FOUND"}, 404
        body = json.dumps(res).encode("utf-8")
        status_text = f"{code} OK" if code == 200 else f"{code} Error"
        start_response(status_text, [("Content-Type", "application/json"), ("Content-Length", str(len(body)))])
        return [body]

    body = b'{"error":"NOT FOUND"}'
    start_response("404 Not Found", [("Content-Type", "application/json"), ("Content-Length", str(len(body)))])
    return [body]


app = wsgi_app


class QuietHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        return

    def _send_bytes(self, body, status=200, content_type="text/html; charset=utf-8", extra_headers=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        if extra_headers:
            for k, v in extra_headers.items():
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        qs = parse_qs(parsed.query)
        if path in ("/", "/pro_ui.html"):
            ui_file = os.path.join(BASE_DIR, "pro_ui.html")
            with open(ui_file, "rb") as f:
                self._send_bytes(f.read(), 200, "text/html; charset=utf-8")
        elif path == "/manifest.json":
            mf_file = os.path.join(BASE_DIR, "manifest.json")
            with open(mf_file, "rb") as f:
                self._send_bytes(f.read(), 200, "application/json")
        elif path == "/sw.js":
            sw_file = os.path.join(BASE_DIR, "sw.js")
            with open(sw_file, "rb") as f:
                self._send_bytes(f.read(), 200, "application/javascript")
        elif path.startswith("/product_images/"):
            rel_name = os.path.basename(path)
            img_path = os.path.join(IMAGES_DIR, rel_name)
            if os.path.isfile(img_path):
                ext = os.path.splitext(rel_name)[1].lower()
                ctype = "image/jpeg" if ext in (".jpg", ".jpeg") else ("image/webp" if ext == ".webp" else "image/png")
                with open(img_path, "rb") as f:
                    self._send_bytes(f.read(), 200, ctype)
            else:
                self._send_bytes(b"NOT FOUND", 404, "text/plain")
        elif path == "/api/state":
            show_cost = (qs.get("show_cost", ["1"])[0] == "1")
            payload = json.dumps(api_get_state(show_cost)).encode("utf-8")
            self._send_bytes(payload, 200, "application/json")
        elif path == "/api/export/stock.csv":
            self._send_bytes(build_stock_csv().encode("utf-8"), 200, "text/csv", {"Content-Disposition": "attachment; filename=gudiya_beautique_stock.csv"})
        elif path == "/api/export/sales.csv":
            self._send_bytes(build_sales_csv().encode("utf-8"), 200, "text/csv", {"Content-Disposition": "attachment; filename=gudiya_beautique_sales.csv"})
        else:
            self._send_bytes(b'{"error":"NOT FOUND"}', 404, "application/json")

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        length = int(self.headers.get("Content-Length", "0") or "0")
        raw = self.rfile.read(length).decode("utf-8") if length > 0 else "{}"
        data = json.loads(raw or "{}")
        if path == "/api/services/delete":
            res, code = api_delete_service(data)
        elif path == "/api/services":
            res, code = api_save_service(data)
        elif path == "/api/products":
            res, code = api_save_product(data)
        elif path == "/api/customers":
            res, code = api_save_customer(data)
        elif path == "/api/suppliers":
            res, code = api_save_supplier(data)
        elif path == "/api/sale":
            res, code = api_create_sale(data)
        elif path == "/api/sale/pay":
            res, code = api_pay_sale_due(data)
        elif path == "/api/purchase":
            res, code = api_create_purchase(data)
        elif path == "/api/purchase/pay":
            res, code = api_pay_purchase_due(data)
        elif path == "/api/purchase/delete":
            res, code = api_delete_purchase(data)
        elif path == "/api/backup":
            res, code = api_create_backup()
        elif path == "/api/custom-images":
            res, code = api_save_custom_image(data)
        else:
            res, code = {"error": "NOT FOUND"}, 404
        self._send_bytes(json.dumps(res).encode("utf-8"), code, "application/json")


if __name__ == "__main__":
    init_db()
    lan_ip = get_lan_ip()
    bound_port = PORT
    server = None
    for candidate_port in [PORT, 56673, 56674, 8080, 0]:
        try:
            server = ReusableThreadingHTTPServer(("0.0.0.0", candidate_port), QuietHandler)
            bound_port = server.server_address[1]
            break
        except OSError:
            server = None

    if server is None:
        print("ERROR: Could not start HTTP server on any port.")
        sys.exit(1)

    url_local = f"http://127.0.0.1:{bound_port}/"
    print("GUDIYA BEAUTIQUE server running:")
    print(f"  PC Browser:     {url_local}")
    print(f"  Mobile Browser: http://{lan_ip}:{bound_port}/  (Same Wi-Fi / Hotspot)")
    open_browser_later(url_local, delay=1.0)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
